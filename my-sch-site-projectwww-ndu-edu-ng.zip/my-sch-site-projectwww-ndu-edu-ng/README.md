# My Sch Site Project - www.ndu.edu.ng 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Lekog/pen/QWmqbxx](https://codepen.io/Lekog/pen/QWmqbxx).

This is a mini clone of the Niger Delta University in Bayelsa State, Nigeria as part of my Schull.io project.  I have worked on the development to have only two precious menus,  namely, Home, About Us and Tetfund while I have disabled the rest in order to save time and also align with the scope of the given project. 